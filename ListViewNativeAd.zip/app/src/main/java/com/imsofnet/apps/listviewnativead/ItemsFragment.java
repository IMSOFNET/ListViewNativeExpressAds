package com.imsofnet.apps.listviewnativead;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.NativeExpressAdView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Okunade Habeeb on 06/08/2017.
 */

public class ItemsFragment extends ListFragment {
    CustomAdapter adapter;
    List<Object> objectList;

    public ItemsFragment(){

    }

    @Override
    public void onResume () {
        super.onResume();
    }

    @Override
    public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_items, container, false);
        setListItems();
        return view;
    }

    private void setListItems(){
        objectList = new ArrayList<>();
        addContactItems();
        addAdsItems();
        adapter = new CustomAdapter(getContext(), objectList);
        if(getListAdapter() == null){
            setListAdapter(adapter);
        }else {
            adapter.notifyDataSetChanged();
        }
    }

    void addContactItems(){
        int numOfContact = 20;
        for(int i=0; i<numOfContact; i++){
            ListItems contactItem =
                    new ListItems(i+1, "Contact "+(i+1)+" Name", "Contact "+(i+1)+" Address",
                            "Contact "+(i+1)+" phone number");
            objectList.add(contactItem);
        }
    }

    void addAdsItems(){
        int numOfAds = 0;
        for(int i=4; i<objectList.size(); i+=5){
            NativeExpressAdView ads = new NativeExpressAdView(getContext());
            objectList.add(i, ads);
            numOfAds++;
            if(numOfAds == CustomAdapter.ADS_MAX)
                break;
        }
    }

    private class CustomAdapter extends BaseAdapter{

        private static final int TYPE_COUNT = 2; // Number of different items to adapt

        private static final int CONTACT_TYPE = 0; // Every contact item
        private static final int ADS_TYPE = 1;  // Every Ads item

        private static final int ADS_MAX = 3;   // Max. number of native ads to show

        private LayoutInflater layoutInflater;
        private List<Object> itemList;
        private Context context;

        public CustomAdapter(Context conxt, List<Object> listItems){
            itemList = listItems;
            context = conxt;
            layoutInflater = (LayoutInflater) context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getItemViewType(int position){
            return ((itemList.get(position) instanceof ListItems) ? CONTACT_TYPE : ADS_TYPE);
        }

        @Override
        public int getViewTypeCount(){
            return TYPE_COUNT;
        }

        @Override
        public int getCount() {
            return itemList.size();
        }

        @Override
        public Object getItem(int position) {
            return itemList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            int type = getItemViewType(position);
            Object item = getItem(position);
            if(convertView == null){
                switch (type){
                    case CONTACT_TYPE:
                        convertView = layoutInflater.inflate(R.layout.contact_items, parent, false);
                        break;
                    case ADS_TYPE:
                        convertView = layoutInflater.inflate(R.layout.ads_items, parent, false);
                        break;
                }
            }
            if(type == ADS_TYPE){
                NativeExpressAdView adView = (NativeExpressAdView) convertView.
                        findViewById(R.id.adView);
                adView.loadAd(new AdRequest.Builder().
                        addTestDevice("46478C50FA8F805D3E63AF768B5336CD").build());
                //adView.loadAd(new AdRequest.Builder().build());
            }else{
                TextView textName = (TextView)convertView.findViewById(R.id.text_name);
                TextView textAddress = (TextView)convertView.findViewById(R.id.text_address);
                TextView textPhone = (TextView)convertView.findViewById(R.id.text_phone);

                ListItems contactItem = (ListItems) item;
                textName.setText(contactItem.getName());
                textAddress.setText(contactItem.getAddress());
                textPhone.setText(contactItem.getPhone());
            }
            Log.e("ItemsFragment","->->-> getView - convertView");
            return convertView;
        }
    }

}
