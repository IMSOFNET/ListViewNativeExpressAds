package com.imsofnet.apps.listviewnativead;

/**
 * Created by Okunade Habeeb on 06/08/2017.
 */

public class ListItems {
    private int id;
    private String name;
    private String address;
    private String phone;

    public ListItems(int id, String name, String address, String phone){
        setId(id);
        setName(name);
        setAddress(address);
        setPhone(phone);
    }
    //Set Methods for this object
    public void setId(int id) {
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    // Get Methods for this object
    public int getId() {
        return this.id;
    }
    public String getName() {
        return this.name;
    }
    public String getAddress() {
        return this.address;
    }
    public String getPhone() {
        return this.phone;
    }
}
